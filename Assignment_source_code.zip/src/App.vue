<template>
  <div id="app" class="bg-seaBlue desk:bg-deskBack">
    <ViewArea msg="Welcome to Your Vue.js App" />
  </div>
</template>

<script>
import ViewArea from "./components/ViewArea.vue";

export default {
  name: "App",
  components: {
    ViewArea,
  },
};
</script>
<style scoped>
</style>