<template>
  <div>
    <button
      @click="captureFiles"
      class="
        flex
        items-center
        justify-center
        bg-blue
        w-52
        h-11
        mb-5
        rounded-lg
        font-medium
        text-base text-white
      "
    >
      <img src="../../assets/cam.svg" alt="camera icon" />
      <p class="ml-2">Use Camera</p>
    </button>
  </div>
</template>

<script>
export default {
  methods: {
    captureFiles(event) {
      this.$emit("capture", event);
    },
  },
};
</script>
