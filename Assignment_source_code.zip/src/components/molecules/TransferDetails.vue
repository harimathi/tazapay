<template>
  <div
    class="
      flex-col flex
      text-base
      flex-wrap
      leading-5
      font-semibold
      tab:flex-row
    "
  >
    <div class="mt-2 w-full tab:w-30% pl-6 tab:mt-0">
      <p class="mb-4 text-blue">Buyer’s Email</p>
      <p>{{ TRANSFER_DETAILS.buyer_email }}</p>
    </div>
    <div class="mt-6 mobile:mt-5 w-full tab:w-30% pl-6 tab:mt-0">
      <p class="mb-4 text-blue">Exporting To</p>
      <p>{{ TRANSFER_DETAILS.importing_from }}</p>
    </div>
    <div class="mt-6 mobile:mt-5 w-full tab:w-30% pl-6 tab:mt-0">
      <p class="mb-4 text-blue">Invoice Amount</p>
      <p>{{ TRANSFER_DETAILS.invoice_amount }}</p>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  computed: {
    ...mapState(["TRANSFER_DETAILS"]),
  },
};
</script>