<template>
  <div class="h-280 w-full rounded-lg desk:rounded-none">
    <div class="absolute mt-38 ml-6 w-84% tab:mt-72 tab:w-2/4">
      <HeadingText
        class="
          mt-8
          mb-2
          text-blue
          font-semibold
          text-lg
          desk:my-8
          desk:text-darkBlue
        "
        :text="SHOW_SHIPPING ? 'Shipping Information' : 'Product Details'"
      />
      <div v-show="SHOW_SHIPPING" class="pl-6">
        <p class="mb-2 font-medium text-coolGray tab:mb-4">Shipping Info</p>
        <p class="mb-1.5 font-normal text-dullGray">Hari</p>
        <p class="mb-1.5 font-normal text-dullGray">
          No 120, Balamurugan gardern
        </p>
        <p class="mb-1.5 font-normal text-dullGray">
          first cross main road , thurapakkam
        </p>
        <p class="mb-1.5 font-normal text-dullGray">chennai-97, TN</p>
      </div>
      <div v-show="!SHOW_SHIPPING">
        <p class="text-darkGray text-sm mb-4 font-medium">
          Placeholder for subtitle
        </p>
        <div class="border-solid border-b border-lightGray mb-6"></div>
        <HeadingText
          class="
            mb-4
            text-grey600 text-base
            font-semibold
            mobile:text-lg
            mobile:mb-6
          "
          text="Upload your Proforma Invoice"
        />
        <FileUpload />
        <div class="flex mt-8 mb-9">
          <div class="h-7 w-7 mr-2">
            <img src="../../assets/add.svg" alt="" />
          </div>
          <p class="text-base text-lightIndigo font-normal">
            Upload another document
          </p>
        </div>
        <div class="border-solid border-b border-centerBorder mb-6"></div>
      </div>
      <Button
        class="hidden absolute right-0 desk:inline-block"
        :disabled="!FILES_COUNT"
        :class="[FILES_COUNT ? 'bg-blue' : 'bg-disableGrey']"
        btnText="Next"
        @btnClick="toggelShipping"
      />
      <Button
        class="inline-block absolute right-0 desk:hidden"
        btnText="Done"
        :disabled="!FILES_COUNT"
        :class="[FILES_COUNT ? 'bg-blue' : 'bg-disableGrey']"
        @btnClick="toggelShipping"
      />
      <div class="mt-20">
        <HeadingText
          class="my-4 text-grey400 text-xl font-semibold"
          :text="SHOW_SHIPPING ? 'Product Details' : 'Shipping Information'"
        />
        <HeadingText
          class="my-4 text-grey400 text-xl font-semibold"
          text="Release Conditions"
        />
        <HeadingText
          class="my-4 text-grey400 text-xl font-semibold"
          text="Payment Details"
        />
      </div>
    </div>
  </div>
</template>

<script>
import FileUpload from "./FileUpload.vue";
import HeadingText from "../atoms/HeadingText.vue";
import Button from "../atoms/Button.vue";
import { mapState, mapMutations } from "vuex";

export default {
  components: {
    HeadingText,
    Button,
    FileUpload,
  },
  computed: {
    ...mapState(["PERCNTAGE_UPLOADED", "FILES_COUNT", "SHOW_SHIPPING"]),
  },
  methods: {
    ...mapMutations(["TOGGLE_SHIPPING"]),
    toggelShipping() {
      this.TOGGLE_SHIPPING();
    },
  },
};
</script>