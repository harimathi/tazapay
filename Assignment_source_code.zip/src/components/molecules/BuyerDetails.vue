<template>
  <div
    class="
      flex-col flex flex-wrap
      leading-5
      mt-12
      text-coolGray text-base
      tab:flex-row
    "
  >
    <div class="flex justify-between w-full px-6 tab:w-30% tab:block tab:pl-6">
      <p class="mb-6 font-semibold text-coolGray tab:mb-4">Buyer’s Details</p>
      <p @click="switchModal" class="text-cyan cursor-pointer">Edit</p>
    </div>
    <div class="w-full pl-6 tab:w-30%">
      <p class="mb-2 font-medium text-coolGray tab:mb-4">Company</p>
      <p class="mb-1.5 font-normal text-dullGray">
        {{ BUYER_DETAILS.company }}
      </p>
      <p class="mb-6 font-normal text-dullGray tab:mb-0">
        {{ BUYER_DETAILS.location }}
      </p>
    </div>
    <div class="w-full pl-6 tab:w-30%">
      <p class="mb-2 font-medium text-coolGray tab:mb-4">Contact Person</p>
      <p class="mb-1.5 font-normal text-dullGray">
        {{ BUYER_DETAILS.contact_person }}
      </p>
      <p class="font-normal text-dullGray">{{ BUYER_DETAILS.contact_email }}</p>
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from "vuex";
export default {
  computed: {
    ...mapState(["BUYER_DETAILS", "SHOW_MODAL"]),
  },
  methods: {
    ...mapMutations(["TOGGLE_MODAL"]),
    switchModal() {
      this.TOGGLE_MODAL();
    },
  },
};
</script>