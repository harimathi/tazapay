<template>
  <div>
    <div class="flex flex-col desk:flex-row">
      <div class="w-full pr-12 mx-6 desk:pr-0 desk:w-1/2">
        <p class="font-semibold text-coolGray">Company</p>
        <Input
          lable="Company Name"
          :value="formdata['company']"
          @input="($value) => (formdata['company'] = $value)"
        />
        <Input
          lable="Location"
          :value="formdata['location']"
          @input="($value) => (formdata['location'] = $value)"
        />
      </div>
      <div class="w-full pr-12 mx-6 mt-6 desk:mt-0 desk:pr-0 desk:w-1/2">
        <p class="font-semibold text-coolGray">Contact Person</p>
        <Input
          lable="Name"
          :value="formdata['contact_person']"
          @input="($value) => (formdata['contact_person'] = $value)"
        />
        <Input
          lable="Email"
          :value="formdata['contact_email']"
          @input="($value) => (formdata['contact_email'] = $value)"
        />
      </div>
    </div>
    <div class="h-28">
      <Button
        class="absolute right-0 mt-7 mr-8 bg-blue"
        btnText="Save"
        @btnClick="sumbmitForm"
      />
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from "vuex";
import Button from "../atoms/Button.vue";
import Input from "../atoms/Input.vue";
export default {
  data() {
    return {
      formdata: {
        company: "",
        contact_email: "",
        contact_person: "",
        location: "",
      },
    };
  },
  components: { Input, Button },
  computed: {
    ...mapState(["BUYER_DETAILS", "SHOW_MODAL"]),
  },
  mounted() {
    this.formdata.company = this.BUYER_DETAILS.company;
    this.formdata.contact_email = this.BUYER_DETAILS.contact_email;
    this.formdata.contact_person = this.BUYER_DETAILS.contact_person;
    this.formdata.location = this.BUYER_DETAILS.location;
  },
  methods: {
    ...mapActions(["UPDATE_BUYER_DETAILS"]),
    ...mapMutations(["TOGGLE_MODAL"]),
    sumbmitForm() {
      this.TOGGLE_MODAL();
      this.UPDATE_BUYER_DETAILS(this.formdata);
    },
  },
};
</script>