module.exports = {
  purge: [
    './public/**/*.html',
    './src/**/*.vue'
  ],
  darkMode: false, // or 'media' or 'class'
  theme: {
    colors: {
      deskBack: '#E5E5E5',
      teal: '#2A7793',
      white: '#ffffff',
      cyan: '#58C5ED',
      shadow: '#F9FAFB',
      chalk: '#FBFDFE',
      grey: '#A0AEC0',
      blue: '#1FA7D9',
      coolGray: '#97A6BA',
      dullGray: '#9FA6B2',
      darkBlue: '#156B8A',
      darkGray: '#756F86',
      lightGray: '#EEEEEE',
      grey600: '#718096',
      grey400: '#CBD5E0',
      innerBorder: '#7C9CBF',
      wheat: '#FFF8F1',
      indigo: '#667EEA',
      lightIndigo: '#6676F3',
      centerBorder: '#CFD8E3',
      disableGrey: '#DBE2EA',
      grey800: '#2D3748',
      seaBlue: '#E9F2F6',
      bgGrey: '#6f6f6f69'
    },
    boxShadow: {
      shadow: '0px 12px 24px rgba(44, 39, 56, 0.02), 0px 24px 48px rgba(44, 39, 56, 0.04);'
    },
    extend: {
      spacing: {
        '30%': '30%',
        '22': '352px',
        '38': '608px',
        '84%': '84%',
        '18': '340px'
      },
      maxWidth: {
        '49': '760px',
        '60': '960px',
        '550': '550px',
        '400': '400px',
      },
      minHeight: {
        '90%': '90%',
      },
      borderWidth: {
        '1.5': '0.094px'
      },
      screens: {
        'pixel': '434px',
        'iphone': '439px',
        'mobile': '600px',
        'tab': '960px',
        'desk': '1100px',
      },
      height: {
        '150': '150vh',
        '180': '180vh',
        '200': '200vh',
        '300': '300vh',
        '280': '280vh',
        '42%': '42%'
      },
      backgroundImage: {
        'border-mob': `url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='8' ry='8' stroke='%237C9CBFFF' stroke-width='1' stroke-dasharray='7' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e")`
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
