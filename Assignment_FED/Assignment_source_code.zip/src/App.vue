<template>
  <div id="app" class="bg-seaBlue desk:bg-deskBack">
    <ViewArea />
  </div>
</template>

<script>
import ViewArea from "./components/ViewArea.vue";

export default {
  name: "App",
  components: {
    ViewArea,
  },
};
</script>
<style scoped>
</style>