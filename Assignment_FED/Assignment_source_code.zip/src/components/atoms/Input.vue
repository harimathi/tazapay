<template>
  <div class="flex flex-col">
    <label class="mt-4 font-medium text-coolGray">{{ lable }}</label>
    <input
      :value="value"
      class="focus:outline-none bg-chalk h-8 border-b border-bgGrey"
      type="text"
      @input="emitValues($event)"
    />
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    lable: String,
    value: String,
  },
  methods: {
    emitValues(event) {
      this.$emit("input", event.target.value);
    },
  },
};
</script>