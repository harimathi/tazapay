<template>
  <button
    :disabled="disabled"
    class="
      w-32
      h-11
      mb-5
      rounded-lg
      font-semibold
      text-base text-white
      absolute
      right-0
    "
    :class="btnClass"
    @click="clickHandler"
  >
    {{ btnText }}
  </button>
</template>

<script>
export default {
  props: {
    btnText: String,
    btnClass: String,
    disabled: Boolean,
  },
  methods: {
    clickHandler() {
      this.$emit("btnClick");
    },
  },
};
</script>