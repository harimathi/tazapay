<template>
  <div @click="caputureUpload" class="flex">
    <p>{{ text }}</p>
    <img
      @click="closeModal"
      v-if="closeBtn"
      class="h-6 w-6 mr-6 right-0 absolute"
      src="../../assets/close.svg"
      alt="close icon"
    />
  </div>
</template>

<script>
import { mapMutations } from "vuex";
export default {
  props: {
    text: {
      type: String,
      default: "Create your first transfer agreement",
    },
    closeBtn: {
      type: Boolean,
      default: false,
    },
  },
  methods: {
    ...mapMutations(["TOGGLE_MODAL"]),
    caputureUpload(event) {
      this.$emit("caputureUpload", event);
    },
    closeModal() {
      this.TOGGLE_MODAL();
    },
  },
};
</script>