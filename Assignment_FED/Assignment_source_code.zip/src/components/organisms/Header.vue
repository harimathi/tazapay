<template>
  <div
    class="
      bg-teal
      h-16
      tab:h-24
      flex
      items-center
      mobile:h-24
      desk:bg-white
      desk:h-16
    "
  >
    <div class="absolute right-0 flex items-center">
      <div
        class="
          h-6
          w-6
          mr-4
          inline-block
          mobile:h-9
          mobile:w-9
          mobile:mr-6
          tab:hidden
        "
      >
        <img src="../../assets/lens.svg" alt="" />
      </div>
      <div
        class="h-8 w-8 mr-6 mobile:h-12 mobile:w-12 desk:h-8 desk:w-8 desk:mr-4"
      >
        <img src="../../assets/name.svg" alt="" />
      </div>
      <p class="hidden mr-10 font-semibold text-base desk:inline-block">
        Nathan Keller
      </p>
    </div>
    <div class="absolute left-0 flex items-center">
      <div
        @click="switchSideNav"
        class="h-6 w-6 ml-4 mobile:ml-6 mobile:h-8 mobile:w-8 desk:hidden"
      >
        <img src="../../assets/menu.svg" alt="" />
      </div>
      <p
        class="
          inline-block
          ml-4
          text-white
          font-semibold
          text-2xl
          mobile:text-3xl
          desk:hidden
        "
      >
        Transfer
      </p>
    </div>
  </div>
</template>

<script>
import { mapMutations } from "vuex";
export default {
  methods: {
    ...mapMutations(["TOGGLE_SIDE_NAV"]),
    switchSideNav() {
      this.TOGGLE_SIDE_NAV();
    },
  },
};
</script>

<style>
</style>