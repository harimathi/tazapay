<template>
  <section class="max-w-2xl tab:max-w-49 desk:max-w-60 m-auto relative">
    <HeadingText
      class="
        my-4
        font-semibold
        text-base text-darkBlue
        pixel:my-6
        pixel:text-xl
      "
    />
    <Transfer
      class="
        absolute
        rounded-b-lg
        h-80
        w-full
        bg-shadow
        top-18
        shadow-shadow
        pixel:top-22
        tab:top-48
        tab:h-40
      "
    />
    <Transfer
      :hasTitle="true"
      :hasBorder="true"
      details="buyer"
      titleText="Transfer Agreement #1"
      titleClass="leading-6 mt-4 ml-6 pixel:mt-6 font-semibold text-grey800 text-base pixel:text-xl"
      class="
        absolute
        rounded-lg
        desk:rounded-b-lg
        bg-chalk
        h-80
        tab:h-40
        w-full
        shadow-shadow
      "
    />
    <ProductDetails class="bg-shadow shadow-shadow" />
  </section>
</template>

<script>
import HeadingText from "../atoms/HeadingText.vue";
import ProductDetails from "../molecules/ProductDetails.vue";
import Transfer from "../molecules/Transfer.vue";
export default {
  components: { HeadingText, ProductDetails, Transfer },
};
</script>

<style>
</style>