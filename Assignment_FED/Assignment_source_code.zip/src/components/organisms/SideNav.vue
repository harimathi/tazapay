<template>
  <div class="absolute h-full bg-teal w-56">
    <img
      @click="switchSideNav"
      class="
        flex
        h-6
        w-6
        mr-2
        mb-4
        mt-4
        ml-48
        fill-current
        text-white
        right-0
        desk:hidden
      "
      src="../../assets/close.svg"
      alt="close icon"
    />
    <div
      class="
        flex
        items-center
        justify-center
        m-auto
        w-40
        h-9
        mt-8
        bg-white
        rounded-lg
        text-base
        font-medium
      "
    >
      Company Logo
    </div>
    <ul class="mt-16 text-white font-semibold text-xl">
      <li class="mb-10 ml-7">Home</li>
      <div class="bg-cyan py-4 pl-7 mb-10">
        <li>Transfer</li>
      </div>
      <li class="mb-10 ml-7">Account</li>
      <li class="mb-10 ml-7">Documents</li>
      <li class="mb-10 ml-7">Reports</li>
    </ul>
  </div>
</template>

<script>
import { mapMutations } from "vuex";
export default {
  methods: {
    ...mapMutations(["TOGGLE_SIDE_NAV"]),
    switchSideNav() {
      this.TOGGLE_SIDE_NAV();
    },
  },
};
</script>

<style>
</style>