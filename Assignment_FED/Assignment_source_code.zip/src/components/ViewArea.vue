<template>
  <div>
    <h1 v-if="API_ERROR" class="text-lg font-semibold">Something went Wrong</h1>
    <div v-else>
      <div class="flex flex-col">
        <Header />
        <SideNav v-show="SHOW_SIDE_NAV" class="z-10" />
      </div>
      <div class="px-4 h-300 m-auto desk:ml-56">
        <ContentArea />
      </div>
      <Modal v-if="SHOW_MODAL" />
      <PageSpinner v-if="DATA_FETCHING" />
    </div>
  </div>
</template>

<script>
import { mapActions, mapState, mapMutations } from "vuex";
import PageSpinner from "./atoms/PageSpinner.vue";
import Modal from "./molecules/Modal.vue";
import ContentArea from "./organisms/ContentArea.vue";
import Header from "./organisms/Header.vue";
import SideNav from "./organisms/SideNav.vue";

export default {
  components: { Header, SideNav, ContentArea, PageSpinner, Modal },
  name: "HelloWorld",
  data() {
    return {
      screenWidth: window.innerWidth,
    };
  },
  props: {
    msg: String,
  },
  watch: {
    screenWidth() {
      if (this.screenWidth < 1100) {
        this.TOGGLE_SIDE_NAV(false);
      } else {
        this.TOGGLE_SIDE_NAV(true);
      }
    },
  },
  computed: {
    ...mapState(["DATA_FETCHING", "SHOW_MODAL", "SHOW_SIDE_NAV", "API_ERROR"]),
  },
  methods: {
    ...mapActions(["GET_JSON_DETAILS"]),
    ...mapMutations(["TOGGLE_SIDE_NAV"]),
  },
  mounted() {
    this.GET_JSON_DETAILS();
    if (this.screenWidth > 1100) {
      this.TOGGLE_SIDE_NAV(true);
    }
    window.addEventListener(
      "resize",
      () => (this.screenWidth = window.innerWidth)
    );
  },

  beforeDestroy() {
    window.removeEventListener(
      "resize",
      () => (this.screenWidth = window.innerWidth)
    );
  },
};
</script>
