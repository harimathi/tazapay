<template>
  <div>
    <HeadingText
      v-if="hasTitle"
      :text="titleText"
      :class="titleClass"
      :closeBtn="closeBtn"
    />
    <div
      v-if="hasBorder"
      class="border-dashed border-b-1.5 border-grey mx-6 my-4"
    ></div>
    <TransferDetails v-if="details === 'buyer'" />
    <EditSection v-else-if="details === 'edit'" />
    <BuyerDetails v-else />
  </div>
</template>

<script>
import HeadingText from "../atoms/HeadingText.vue";
import BuyerDetails from "./BuyerDetails.vue";
import EditSection from "./EditSection.vue";
import TransferDetails from "./TransferDetails.vue";
export default {
  components: { HeadingText, TransferDetails, BuyerDetails, EditSection },
  props: {
    hasTitle: {
      type: Boolean,
      default: false,
    },
    titleText: {
      type: String,
    },
    titleClass: {
      type: String,
    },
    hasBorder: {
      type: Boolean,
      default: false,
    },
    details: {
      type: String,
      default: "transfer",
    },
    closeBtn: {
      type: Boolean,
    },
  },
};
</script>