<template>
  <div
    class="
      flex
      w-full
      h-screen
      top-0
      left-0
      fixed
      bg-bgGrey
      items-center
      justify-center
    "
  >
    <Transfer
      :hasTitle="true"
      :hasBorder="true"
      details="edit"
      :closeBtn="true"
      titleText="Buyer Details"
      titleClass="leading-6 mt-4 ml-6 pixel:mt-6 font-semibold text-grey800 text-base pixel:text-xl"
      class="
        absolute
        rounded-lg
        bg-chalk
        h-3/4
        w-11/12 w-1/2
        shadow-shadow
        min-h-90%
        overflow-y-scroll
        mobile:max-w-400
        tab:max-w-550
        desk:max-w-49
        desk:min-h-0
        desk:h-42%
        desk:rounded-b-lg
      "
    />
  </div>
</template>

<script>
import Transfer from "./Transfer.vue";
export default {
  components: { Transfer },
};
</script>