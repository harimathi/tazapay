<template>
  <div>
    <div
      @drop.prevent="onDrop"
      @dragover.prevent="onDrag"
      @dragstart="onDragStart"
      class="
        h-44
        p-6
        w-full
        rounded-lg
        flex flex-col
        justify-center
        items-start
        bg-border-mob
        desk:border-dashed desk:border desk:border-innerBorder
        desk:bg-none desk:bg-wheat
      "
    >
      <div
        v-if="PERCNTAGE_UPLOADED"
        class="absolute w-full justify-center items-center flex pr-14 text-3xl"
      >
        {{ PERCNTAGE_UPLOADED }}%
      </div>
      <div
        class="hidden desk:inline-block"
        :class="[
          PERCNTAGE_UPLOADED
            ? 'opacity-30 pointer-events-none'
            : 'opacity-100 pointer-events-auto',
        ]"
      >
        <div class="flex mb-3.5">
          <div class="h-7 w-7 mr-4">
            <img src="../../assets/upload.svg" alt="" />
          </div>
          <HeadingText
            class="text-indigo text-lg font-semibold"
            text="Drop Proforma Invoice Here"
          />
        </div>
        <input
          type="file"
          ref="fileInput"
          multiple
          accept=".pdf, .jpg, .png, .csv, .xls"
          class="hidden"
          @change="onDrop"
        />
        <p class="text-sm mb-2 text-grey600">
          or
          <span class="text-indigo cursor-pointer" @click="selectFiles"
            >Browse</span
          >
          from your computer
        </p>
        <p class="text-xs text-grey">
          Acceptable formats - pdf, .jpg. png, .csv, excel
        </p>
      </div>
      <div
        class="
          inline-block
          w-full
          flex flex-col
          justify-center
          items-center
          desk:hidden
        "
        :class="[
          PERCNTAGE_UPLOADED
            ? 'opacity-30 pointer-events-none'
            : 'opacity-100 pointer-events-auto',
        ]"
      >
        <input
          type="file"
          ref="caputureInput"
          accept="image/*"
          class="hidden"
          capture="environment"
          @change="onDrop"
        />
        <input
          type="file"
          ref="caputureUpload"
          accept="image/*"
          class="hidden"
          @change="onDrop"
        />
        <IconButton class="mt-4" @capture="capture" />
        <div class="flex items-center w-3/6">
          <div class="border-solid border-b border-grey w-2/5"></div>
          <span class="w-1/5 text-center">or</span>
          <div class="border-solid border-b border-grey w-2/5"></div>
        </div>
        <div class="flex mb-3.5 items-center mt-4">
          <div class="h-7 w-7 mr-4">
            <img src="../../assets/slide.svg" alt="" />
          </div>
          <HeadingText
            @caputureUpload="caputureUpload"
            class="text-indigo text-base font-medium cursor-pointer"
            text="Select from the Gallery"
          />
        </div>
      </div>
    </div>
    <p v-if="FILES_COUNT" class="text-sm my-2 text-grey600">
      {{ FILES_COUNT }} files
      {{ PERCNTAGE_UPLOADED ? "uploading" : "uploaded" }}
    </p>
  </div>
</template>

<script>
import HeadingText from "../atoms/HeadingText.vue";
import IconButton from "../atoms/IconButton.vue";
import { mapState, mapActions, mapMutations } from "vuex";
export default {
  data() {
    return {
      dragEffect: false,
    };
  },
  components: { HeadingText, IconButton },
  computed: {
    ...mapState(["PERCNTAGE_UPLOADED", "FILES_COUNT"]),
  },
  watch: {
    PERCNTAGE_UPLOADED() {
      if (this.PERCNTAGE_UPLOADED === 100) {
        this.SET_PERCNTAGE_UPLOADED(0);
      }
    },
  },
  methods: {
    ...mapActions(["GET_UPLOAD_PROGRESS"]),
    ...mapMutations(["SET_PERCNTAGE_UPLOADED"]),

    onDrag(event) {
      event.dataTransfer.dropEffect = "move";
    },
    onDrop(event) {
      let uploadedFiles;

      if (event?.dataTransfer?.files) {
        uploadedFiles = event?.dataTransfer?.files;
      } else {
        uploadedFiles = event?.target?.files;
      }
      this.GET_UPLOAD_PROGRESS(uploadedFiles);
    },
    onDragStart(event) {
      event.dataTransfer.dropEffect = "move";
    },
    selectFiles() {
      this.$refs.fileInput.click();
    },
    capture() {
      this.$refs.caputureInput.click();
    },
    caputureUpload() {
      this.$refs.caputureUpload.click();
    },
  },
};
</script>

<style>
.visually-hidden {
  position: absolute !important;
  height: 1px;
  width: 1px;
  overflow: hidden;
  clip: rect(1px, 1px, 1px, 1px);
}

/* Separate rule for compatibility, :focus-within is required on modern Firefox and Chrome */
input.visually-hidden:focus + label {
  outline: thin dotted;
}
input.visually-hidden:focus-within + label {
  outline: thin dotted;
}
</style>