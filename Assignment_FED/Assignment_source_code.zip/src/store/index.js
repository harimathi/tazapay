import Vue from 'vue'
import Vuex from 'vuex'
import axios from "axios";

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    TRANSFER_DETAILS: {},
    BUYER_DETAILS: {},
    DATA_FETCHING: false,
    PERCNTAGE_UPLOADED: 0,
    FILES_COUNT: 0,
    SHOW_MODAL: false,
    SHOW_SHIPPING: false,
    SHOW_SIDE_NAV: false,
    API_ERROR: false,
  },
  mutations: {
    SET_TRANSFER_DETAILS(state, data) {
      state.TRANSFER_DETAILS = data
    },
    SET_BUYER_DETAILS(state, data) {
      state.BUYER_DETAILS = data
    },
    SET_PERCNTAGE_UPLOADED(state, data) {
      state.PERCNTAGE_UPLOADED = data
    },
    TOGGLE_MODAL(state) {
      state.SHOW_MODAL = !state.SHOW_MODAL
    },
    TOGGLE_SHIPPING(state) {
      state.SHOW_SHIPPING = !state.SHOW_SHIPPING
    },
    TOGGLE_SIDE_NAV(state, payload) {
      state.SHOW_SIDE_NAV = payload ?? !state.SHOW_SIDE_NAV
    },
  },
  actions: {
    async GET_JSON_DETAILS({ state, commit }) {
      state.DATA_FETCHING = true;
      await axios
        .get(`https://my-json-server.typicode.com/harimathi/json_db/json_details`)
        .then((response) => {
          if (response?.data) {
            const tansferData = response?.data
            commit('SET_TRANSFER_DETAILS', tansferData[0])
            commit('SET_BUYER_DETAILS', tansferData[1])
            state.DATA_FETCHING = false;
          }
        })
        .catch((e) => {
          state.DATA_FETCHING = false;
          state.API_ERROR = true;
          console.log(e)
        });
    },
    async UPDATE_BUYER_DETAILS({ state, commit }, buyerData) {
      state.DATA_FETCHING = true;
      await axios
        .put(`https://my-json-server.typicode.com/harimathi/json_db/json_details/buyer_details/`, buyerData)
        .then((response) => {
          if (response?.data) {
            const tansferData = response?.data
            commit('SET_BUYER_DETAILS', tansferData)
            state.DATA_FETCHING = false;
          }
        })
        .catch((e) => {
          state.DATA_FETCHING = false;
          state.API_ERROR = true;
          console.log(e)
        });
    },

    async GET_UPLOAD_PROGRESS({ state }, uploadedFiles) {
      console.log(uploadedFiles)
      const fd = new FormData();
      state.FILES_COUNT = 0;
      for (const file in uploadedFiles) {
        if (Object.hasOwnProperty.call(uploadedFiles, file)) {
          fd.append("file", uploadedFiles[file]);
          state.FILES_COUNT++;
        }
      }

      await axios
        .put(
          "https://my-json-server.typicode.com/harimathi/json_db/json_details/form_data",
          fd,
          {
            onUploadProgress: function (progressEvent) {
              state.PERCNTAGE_UPLOADED = parseInt(
                Math.round((progressEvent.loaded / progressEvent.total) * 100)
              );
            }.bind(this),
          }
        )
        .then(function (res) {
          console.log(res);
        })
        .catch(function (err) {
          console.log(err);
        });
    }
  },
  modules: {
  }
})
